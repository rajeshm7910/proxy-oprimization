content = context.getVariable("request.content");
context.setVariable("content", content);
