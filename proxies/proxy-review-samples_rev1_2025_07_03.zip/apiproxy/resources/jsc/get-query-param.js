key=context.getVariable("request.queryparam.apikey");
context.setVariable("key", key);